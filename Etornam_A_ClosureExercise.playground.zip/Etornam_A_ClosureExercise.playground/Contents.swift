import UIKit
// variables
func justMathin (a: Int, b: Int) -> Int {
    return a * b
}
// operation
var multiply: (Int, Int) -> Int = justMathin
print("Result: \(multiply( 5, 4))")
